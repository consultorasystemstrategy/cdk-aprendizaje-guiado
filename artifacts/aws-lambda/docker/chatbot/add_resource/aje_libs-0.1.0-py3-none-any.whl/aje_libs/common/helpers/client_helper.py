import json
import os
from typing import Optional, Any, List
from contextlib import AsyncExitStack
from mcp.client.streamable_http import streamablehttp_client
from mcp import ClientSession, StdioServerParameters
from ...common.logger import custom_logger
from .tools_helper import ToolsHelper

logger = custom_logger(__name__)

class ClientHelper:
    """Helper principal para interactuar con las herramientas del MCP Server."""
    
    def __init__(self):
        """
        Inicializa el MCP Cliente.
        
        :param region_name: Región de AWS
        """
        self.session: Optional[ClientSession] = None
        self.exit_stack = AsyncExitStack()
        self.tools = ToolsHelper()

    async def connect_to_server(self):
        # print(f"Connecting to MCP HTTP server at: {endpoint}")
        # url = (f"{endpoint}/mcp" if not endpoint.endswith('/mcp') else endpoint)

        http_client = await self.exit_stack.enter_async_context(
            streamablehttp_client(
                url="https://b750bxrjzd.execute-api.us-east-1.amazonaws.com/dev/api/v1/server",
                # headers={"Authorization": f"Bearer {os.getenv('AUTH_TOKEN')}"}
            )
        )
        self.read, self.write, _ = http_client

        logger("Creating client session...")
        self.session = await self.exit_stack.enter_async_context(ClientSession(self.read, self.write))

        logger("Initializing session...")
        await self.session.initialize()

        # Recuperar herramientas disponibles
        logger("Retrieving available tools...")
        await self.get_available_tools()

    async def get_available_tools(self) -> List[Any]:
        tools_response = await self.session.list_tools()
        tools = []

        if hasattr(tools_response, 'tools'):
            tools = tools_response.tools
        elif isinstance(tools_response, dict) and 'tools' in tools_response:
            tools = tools_response['tools']

        if not tools:
            print("No tools available in the session.")
            self.tools.register_tool(
                name="help",
                func=lambda x: f"This is a help function",
                description="Get help about available tools or commands.",
                input_schema={'json': {"type": "object", "properties": {}, "required": []}}
            )
            return

        for tool in tools:
            try:
                name = getattr(tool, 'name', None)
                description = getattr(tool, 'description', "No description")
                schema = getattr(tool, 'inputSchema', {})

                if not name:
                    continue

                input_schema = {
                    "type": "object",
                    "properties": schema.get("properties", {}),
                    "required": schema.get("required", [])
                }

                self.tools.register_tool(
                    name=name,
                    func=self.call_tool,
                    description=description,
                    input_schema={'json': input_schema}
                )
                print(f"Tool registered: {name}")
            except Exception as e:
                print(f"Failed to register tool {tool}: {e}")
    
    async def call_tool(self, tool_name: str, arguments: dict) -> Any:
        """Call a tool with given arguments"""
        if not self.session:
            raise RuntimeError("Not connected to MCP server")
        
        result = await self.session.call_tool(tool_name, arguments=arguments)
        print(f"Tool {tool_name} called with arguments {arguments}, result: {result}")
        return result